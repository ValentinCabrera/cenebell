from django.apps import AppConfig


class SaludConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "Salud"
