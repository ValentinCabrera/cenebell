from django.apps import AppConfig


class MaquinasConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "maquinas"
